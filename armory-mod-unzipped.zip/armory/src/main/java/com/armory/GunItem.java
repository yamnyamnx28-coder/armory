package com.armory;

import java.util.function.Predicate;

import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.projectile.ProjectileUtil;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

/** Hitscan gun: shoots instantly along the look direction. */
public class GunItem extends Item {
	private final float damage;
	private final double range;
	private final int cooldown;
	private final int pellets;
	private final float spread;
	private final float pitch;

	public GunItem(Properties props, float damage, double range, int cooldown, int pellets, float spread, float pitch) {
		super(props);
		this.damage = damage;
		this.range = range;
		this.cooldown = cooldown;
		this.pellets = pellets;
		this.spread = spread;
		this.pitch = pitch;
	}

	@Override
	public InteractionResult use(Level level, Player player, InteractionHand hand) {
		if (level instanceof ServerLevel server) {
			ItemStack stack = player.getItemInHand(hand);
			Vec3 from = player.getEyePosition();

			for (int i = 0; i < pellets; i++) {
				Vec3 dir = player.getLookAngle();
				if (spread > 0) {
					dir = dir.add(
						(player.getRandom().nextDouble() - 0.5) * spread,
						(player.getRandom().nextDouble() - 0.5) * spread,
						(player.getRandom().nextDouble() - 0.5) * spread).normalize();
				}
				Vec3 to = from.add(dir.scale(range));

				// stop at walls
				HitResult wall = server.clip(new ClipContext(from, to, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, player));
				if (wall.getType() != HitResult.Type.MISS) {
					to = wall.getLocation();
				}

				AABB box = new AABB(from, to).inflate(1.0);
				Predicate<Entity> filter = e -> !e.isSpectator() && e.isPickable() && e != player;
				EntityHitResult hit = ProjectileUtil.getEntityHitResult(player, from, to, box, filter, range * range);
				if (hit != null) {
					DamageSource source = server.damageSources().playerAttack(player);
					hit.getEntity().hurtServer(server, source, damage);
					to = hit.getLocation();
				}

				// tracer particles
				Vec3 step = to.subtract(from);
				int n = (int) Math.min(40, step.length() * 2);
				for (int k = 1; k <= n; k++) {
					Vec3 p = from.add(step.scale(k / (double) n));
					server.sendParticles(ParticleTypes.CRIT, p.x, p.y, p.z, 1, 0, 0, 0, 0);
				}
			}

			server.playSound(null, player.getX(), player.getY(), player.getZ(),
				SoundEvents.FIREWORK_ROCKET_BLAST, SoundSource.PLAYERS, 1.0f, pitch);
			player.getCooldowns().addCooldown(stack, cooldown);
		}
		return InteractionResult.SUCCESS;
	}
}
