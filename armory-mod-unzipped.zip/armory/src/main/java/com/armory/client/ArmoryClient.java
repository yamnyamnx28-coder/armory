package com.armory.client;

import com.armory.Armory;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;
import net.minecraft.client.renderer.entity.ZombieRenderer;

public class ArmoryClient implements ClientModInitializer {
	@Override
	public void onInitializeClient() {
		// Bosses look like big zombies for now
		EntityRendererRegistry.register(Armory.DARK_GUARDIAN, ZombieRenderer::new);
		EntityRendererRegistry.register(Armory.LAVA_KING, ZombieRenderer::new);
		EntityRendererRegistry.register(Armory.STORM_TITAN, ZombieRenderer::new);
	}
}
