package com.armory;

import java.util.function.Function;

import com.armory.entity.DarkGuardian;
import com.armory.entity.LavaKing;
import com.armory.entity.StormTitan;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.SpawnEggItem;
import net.minecraft.world.item.ToolMaterial;

public class Armory implements ModInitializer {
	public static final String MOD_ID = "armory";

	public static Identifier id(String path) {
		return Identifier.fromNamespaceAndPath(MOD_ID, path);
	}

	private static Item register(String name, Function<Item.Properties, Item> factory) {
		ResourceKey<Item> key = ResourceKey.create(Registries.ITEM, id(name));
		Item item = factory.apply(new Item.Properties().setId(key).stacksTo(1));
		return Registry.register(BuiltInRegistries.ITEM, key, item);
	}

	private static <T extends Entity> EntityType<T> registerEntity(String name, EntityType.Builder<T> builder) {
		ResourceKey<EntityType<?>> key = ResourceKey.create(Registries.ENTITY_TYPE, id(name));
		return Registry.register(BuiltInRegistries.ENTITY_TYPE, key, builder.build(key));
	}

	// ---- Weapons ----          damage range cooldown pellets spread pitch
	public static final Item PISTOL  = register("pistol",  p -> new GunItem(p,  6f,  60, 8,  1, 0f,    1.6f));
	public static final Item SMG     = register("smg",     p -> new GunItem(p,  3f,  45, 2,  1, 0.05f, 2.0f));
	public static final Item SHOTGUN = register("shotgun", p -> new GunItem(p,  3f,  18, 25, 8, 0.25f, 0.7f));
	public static final Item SNIPER  = register("sniper",  p -> new GunItem(p, 20f, 150, 40, 1, 0f,    0.5f));
	public static final Item LASER_SWORD = register("laser_sword",
		p -> new Item(p.sword(ToolMaterial.DIAMOND, 7f, -2.0f)));
	public static final Item ASH_IGNITER = register("ash_igniter", AshIgniterItem::new);

	// ---- Bosses ----
	public static final EntityType<DarkGuardian> DARK_GUARDIAN = registerEntity("dark_guardian",
		EntityType.Builder.of(DarkGuardian::new, MobCategory.MONSTER).sized(0.6f, 1.95f).clientTrackingRange(10).fireImmune());
	public static final EntityType<LavaKing> LAVA_KING = registerEntity("lava_king",
		EntityType.Builder.of(LavaKing::new, MobCategory.MONSTER).sized(0.6f, 1.95f).clientTrackingRange(10).fireImmune());
	public static final EntityType<StormTitan> STORM_TITAN = registerEntity("storm_titan",
		EntityType.Builder.of(StormTitan::new, MobCategory.MONSTER).sized(0.6f, 1.95f).clientTrackingRange(10).fireImmune());

	public static final Item DARK_GUARDIAN_EGG = register("dark_guardian_spawn_egg", p -> new SpawnEggItem(p.spawnEgg(DARK_GUARDIAN)));
	public static final Item LAVA_KING_EGG = register("lava_king_spawn_egg", p -> new SpawnEggItem(p.spawnEgg(LAVA_KING)));
	public static final Item STORM_TITAN_EGG = register("storm_titan_spawn_egg", p -> new SpawnEggItem(p.spawnEgg(STORM_TITAN)));

	@Override
	public void onInitialize() {
		FabricDefaultAttributeRegistry.register(DARK_GUARDIAN, DarkGuardian.createAttributes());
		FabricDefaultAttributeRegistry.register(LAVA_KING, LavaKing.createAttributes());
		FabricDefaultAttributeRegistry.register(STORM_TITAN, StormTitan.createAttributes());

		ItemGroupEvents.modifyEntriesEvent(CreativeModeTabs.COMBAT).register(entries -> {
			entries.accept(PISTOL);
			entries.accept(SMG);
			entries.accept(SHOTGUN);
			entries.accept(SNIPER);
			entries.accept(LASER_SWORD);
		});
		ItemGroupEvents.modifyEntriesEvent(CreativeModeTabs.TOOLS_AND_UTILITIES).register(e -> e.accept(ASH_IGNITER));
		ItemGroupEvents.modifyEntriesEvent(CreativeModeTabs.SPAWN_EGGS).register(e -> {
			e.accept(DARK_GUARDIAN_EGG);
			e.accept(LAVA_KING_EGG);
			e.accept(STORM_TITAN_EGG);
		});
	}
}
