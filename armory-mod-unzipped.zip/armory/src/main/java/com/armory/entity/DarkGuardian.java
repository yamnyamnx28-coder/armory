package com.armory.entity;

import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.BossEvent;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.monster.Zombie;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;

/** Boss 1: Dark Guardian - shockwave. */
public class DarkGuardian extends BossBase {
	public DarkGuardian(EntityType<? extends DarkGuardian> type, Level level) {
		super(type, level, BossEvent.BossBarColor.PURPLE, 100, 200);
	}

	public static AttributeSupplier.Builder createAttributes() {
		return Zombie.createAttributes()
			.add(Attributes.MAX_HEALTH, 300.0)
			.add(Attributes.ATTACK_DAMAGE, 12.0)
			.add(Attributes.MOVEMENT_SPEED, 0.28)
			.add(Attributes.KNOCKBACK_RESISTANCE, 1.0)
			.add(Attributes.ARMOR, 10.0)
			.add(Attributes.FOLLOW_RANGE, 48.0)
			.add(Attributes.SCALE, 2.0);
	}

	@Override
	protected void special(ServerLevel level) {
		for (Player p : level.getEntitiesOfClass(Player.class, this.getBoundingBox().inflate(8.0))) {
			p.hurtServer(level, level.damageSources().mobAttack(this), 8.0f);
			p.push(0.0, 0.8, 0.0);
			p.hurtMarked = true;
		}
		level.sendParticles(ParticleTypes.EXPLOSION, getX(), getY() + 0.5, getZ(), 20, 3.0, 0.2, 3.0, 0.0);
	}
}
