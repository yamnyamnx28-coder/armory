package com.armory.entity;

import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.BossEvent;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LightningBolt;
import net.minecraft.world.entity.EntitySpawnReason;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.monster.Zombie;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;

/** Boss 3: Storm Titan - calls lightning on players. */
public class StormTitan extends BossBase {
	public StormTitan(EntityType<? extends StormTitan> type, Level level) {
		super(type, level, BossEvent.BossBarColor.BLUE, 70, 400);
	}

	public static AttributeSupplier.Builder createAttributes() {
		return Zombie.createAttributes()
			.add(Attributes.MAX_HEALTH, 600.0)
			.add(Attributes.ATTACK_DAMAGE, 16.0)
			.add(Attributes.MOVEMENT_SPEED, 0.30)
			.add(Attributes.KNOCKBACK_RESISTANCE, 1.0)
			.add(Attributes.ARMOR, 14.0)
			.add(Attributes.FOLLOW_RANGE, 64.0)
			.add(Attributes.SCALE, 3.0);
	}

	@Override
	protected void special(ServerLevel level) {
		for (Player p : level.getEntitiesOfClass(Player.class, this.getBoundingBox().inflate(24.0))) {
			LightningBolt bolt = EntityType.LIGHTNING_BOLT.create(level, EntitySpawnReason.TRIGGERED);
			if (bolt != null) {
				bolt.setPos(p.getX(), p.getY(), p.getZ());
				level.addFreshEntity(bolt);
			}
		}
	}
}
