package com.armory.entity;

import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.BossEvent;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.monster.Zombie;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;

/** Boss 2: Lava King - sets nearby players on fire. */
public class LavaKing extends BossBase {
	public LavaKing(EntityType<? extends LavaKing> type, Level level) {
		super(type, level, BossEvent.BossBarColor.RED, 80, 300);
	}

	public static AttributeSupplier.Builder createAttributes() {
		return Zombie.createAttributes()
			.add(Attributes.MAX_HEALTH, 450.0)
			.add(Attributes.ATTACK_DAMAGE, 14.0)
			.add(Attributes.MOVEMENT_SPEED, 0.27)
			.add(Attributes.KNOCKBACK_RESISTANCE, 1.0)
			.add(Attributes.ARMOR, 12.0)
			.add(Attributes.FOLLOW_RANGE, 48.0)
			.add(Attributes.SCALE, 2.5);
	}

	@Override
	protected void special(ServerLevel level) {
		for (Player p : level.getEntitiesOfClass(Player.class, this.getBoundingBox().inflate(12.0))) {
			p.hurtServer(level, level.damageSources().mobAttack(this), 6.0f);
			p.igniteForSeconds(6.0f);
		}
		level.sendParticles(ParticleTypes.LAVA, getX(), getY() + 1.0, getZ(), 40, 4.0, 1.0, 4.0, 0.0);
		level.sendParticles(ParticleTypes.FLAME, getX(), getY() + 1.0, getZ(), 60, 5.0, 1.0, 5.0, 0.05);
	}
}
