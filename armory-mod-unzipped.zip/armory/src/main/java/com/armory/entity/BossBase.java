package com.armory.entity;

import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerBossEvent;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.BossEvent;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.monster.Zombie;
import net.minecraft.world.level.Level;

/** Base for all bosses: zombie body, boss bar, special attack every N ticks. */
public abstract class BossBase extends Zombie {
	private final ServerBossEvent bossBar;
	private final int interval;

	protected BossBase(EntityType<? extends BossBase> type, Level level, BossEvent.BossBarColor color, int interval, int xp) {
		super(type, level);
		this.bossBar = new ServerBossEvent(Component.translatable(type.getDescriptionId()), color, BossEvent.BossBarOverlay.PROGRESS);
		this.interval = interval;
		this.xpReward = xp;
	}

	protected abstract void special(ServerLevel level);

	public boolean convertsInWater() {
		return false;
	}

	@Override
	public boolean removeWhenFarAway(double distance) {
		return false;
	}

	@Override
	protected void customServerAiStep(ServerLevel level) {
		super.customServerAiStep(level);
		bossBar.setProgress(this.getHealth() / this.getMaxHealth());
		if (this.tickCount % interval == 0 && this.getTarget() != null) {
			special(level);
		}
	}

	@Override
	public void startSeenByPlayer(ServerPlayer player) {
		super.startSeenByPlayer(player);
		bossBar.addPlayer(player);
	}

	@Override
	public void stopSeenByPlayer(ServerPlayer player) {
		super.stopSeenByPlayer(player);
		bossBar.removePlayer(player);
	}
}
