package com.armory;

import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.level.portal.TeleportTransition;
import net.minecraft.world.phys.Vec3;

/** Use it to travel between the Overworld and the Ash dimension. */
public class AshIgniterItem extends Item {
	public static final ResourceKey<Level> ASH = ResourceKey.create(Registries.DIMENSION, Armory.id("ash"));

	public AshIgniterItem(Properties props) {
		super(props);
	}

	@Override
	public InteractionResult use(Level level, Player player, InteractionHand hand) {
		if (level instanceof ServerLevel server && player instanceof ServerPlayer sp) {
			int x = player.getBlockX();
			int z = player.getBlockZ();
			ServerLevel target;
			int y;
			if (level.dimension() == ASH) {
				target = server.getServer().overworld();
				y = target.getHeight(Heightmap.Types.MOTION_BLOCKING, x, z);
			} else {
				target = server.getServer().getLevel(ASH);
				y = 64;
				if (target != null) {
					// safe platform + clear air above
					for (int dx = -2; dx <= 2; dx++) {
						for (int dz = -2; dz <= 2; dz++) {
							target.setBlockAndUpdate(new BlockPos(x + dx, y - 1, z + dz), Blocks.OBSIDIAN.defaultBlockState());
							for (int dy = 0; dy < 4; dy++) {
								target.setBlockAndUpdate(new BlockPos(x + dx, y + dy, z + dz), Blocks.AIR.defaultBlockState());
							}
						}
					}
				}
			}
			if (target != null) {
				sp.teleport(new TeleportTransition(target, new Vec3(x + 0.5, y, z + 0.5), Vec3.ZERO,
					player.getYRot(), player.getXRot(), TeleportTransition.DO_NOTHING));
			}
		}
		return InteractionResult.SUCCESS;
	}
}
