@echo off
call gradlew.bat build
echo.
echo Done. Your mod is in build\libs\ (use the file WITHOUT -sources)
pause
